You would write a README for the competition configuration here.

This is where the admins information will go.

Stuff to hand out to the participants goes in writeup.md/writeup.pdf

Make sure to explain scoring and setup scripts here.

Note: Provisioning and scoring run via the Proxmox console (raw exec), not SSH. If your container images do not include an SSH server and you want SSH access, ensure your setup scripts install and enable OpenSSH (or your distro equivalent).
