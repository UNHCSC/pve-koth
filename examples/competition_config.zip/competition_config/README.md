You would write a README for the competition configuration here.

This is where the admins information will go.

Stuff to hand out to the participants goes in writeup.md/writeup.pdf

Make sure to explain scoring and setup scripts here.