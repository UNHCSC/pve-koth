This is where you will write a handout to the competition participants and observers.

This shouldn't reveal everything you're doing, but should give enough information for people to understand the general approach you took and how to approach the event.

Feel free to larp as much as you want here.

This should be converted to a PDF before handing out to make it printable and visually appealing.